#include <iostream>
#include "json.h"
#include "HttpSession.hpp"
#include "CountEvent.hpp"
#include "CountProcessor.hpp"
#include <fstream>
#include <ctime>
#include <string>
CountProcessor::CountProcessor() : GetImageEngine(){
    
}
CountProcessor::~CountProcessor(){
    std::cout << "Destructor CountProcessor" << std::endl;
}
void CountProcessor::handleRequest(std::string& message){
    std::cout << "Get Count Event" << std::endl;
    auto j = json::parse(message);
    if (message != "[]"){
        std::cout << "j.size() = " << j.size() << std::endl;
        for (int i = j.size() - 1; i > -1; i--) {
            auto jlocations = j[i]["extras"]["objects"];
            for (auto jlocations1 : jlocations){
                auto p1 = jlocations1["locations"];
                cv::Rect box(p1[0], p1[1], p1[2], p1[3]);
                this->boxes.push_back(box);
            }  
            this->eventID = j[i]["eventId"];
            std::cout <<" eventId = " << j[i]["eventId"] << std::endl;
            std::string imageID = j[i]["image_id"];
            std::cout << "imageID = "<< imageID << std::endl;
            this->timeEvent = j[i]["time"];
            std::string currentFrameUrl = urlFrame + imageID + "?access_token=" + this->access_token;
            this->getImage(currentFrameUrl);
            drawBox();
            if (!this->imageEvent.empty()){
                std::string name = nameImage();
                cv::imwrite(name, this->imageEvent);
                std::cout << "--------writed done--------" << std::endl;
            }
            this->boxes.clear();
        }
        std::cout << "lastId new = "<< j[0]["eventId"] << std::endl;
        this->lastID = j[0]["eventId"];
    }   
}
std::string CountProcessor::nameImage(){
    int a = this->boxes.size();
    std::string nameImage = "../Event/" + this->ipcamera + "/personcount/" + this->timeEvent + "_" + std::to_string(this->eventID) + "_size_" + std::to_string(a) + ".jpg";
    return nameImage;
}

